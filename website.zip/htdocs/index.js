// 1. UI Setup & Toggle Logic
let isLoginMode = true;
const form = document.getElementById('auth-form');
const emailGroup = document.getElementById('email-group');
const submitBtn = document.getElementById('submit-btn');
const btnText = document.getElementById('btn-text');

function toggleMode() {
    isLoginMode = !isLoginMode;
    
    // Palitan ang mga Text
    document.getElementById('auth-title').innerText = isLoginMode ? "Welcome Back" : "Create Account";
    document.getElementById('auth-subtitle').innerText = isLoginMode ? "Please enter your details" : "Join Bhea Cay Aesthetic";
    btnText.innerText = isLoginMode ? "Sign In" : "Sign Up";
    
    // Ipakita/Itago ang Email field
    emailGroup.classList.toggle('hidden', isLoginMode);
    document.getElementById('email-input').required = !isLoginMode;
    document.getElementById('btn-forgot').classList.toggle('hidden', !isLoginMode);

    // I-update ang Toggle link text
    document.getElementById('toggle-text').innerHTML = isLoginMode 
        ? `Don't have an account? <button type="button" onclick="toggleMode()" class="text-[#B48C64] font-bold hover:underline ml-1">Create Account</button>`
        : `Already have an account? <button type="button" onclick="toggleMode()" class="text-[#B48C64] font-bold hover:underline ml-1">Sign In</button>`;

    lucide.createIcons(); // Refresh icons after DOM change
}

// 2. Form Submission (The "Active" Part)
form.addEventListener('submit', async (e) => {
    e.preventDefault();
    
    // Loading State
    const originalBtnHTML = submitBtn.innerHTML;
    submitBtn.disabled = true;
    submitBtn.innerHTML = `<span class="animate-pulse">Processing...</span>`;

    const payload = {
        username: document.getElementById('user-input').value,
        password: document.getElementById('pass-input').value,
        email: isLoginMode ? null : document.getElementById('email-input').value
    };

    // Determine target API action
    const action = isLoginMode ? 'login' : 'signup';

    try {
        const response = await fetch(`auth_api.php?action=${action}`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        });

        const result = await response.json();

        if (result.status === 'success') {
            if (isLoginMode) {
                // Redirect sa inventory mo
                window.location.href = 'dashboard_inventory.php'; 
            } else {
                alert("✨ Account created! You can now sign in.");
                toggleMode(); // Balik sa login screen
                form.reset();
            }
        } else {
            alert("❌ " + result.message);
        }
    } catch (error) {
        console.error("Auth Error:", error);
        alert("Connection error. Is your server running?");
    } finally {
        submitBtn.disabled = false;
        submitBtn.innerHTML = originalBtnHTML;
    }
});

// Reset Function (Para sa UI Reset button)
document.getElementById('btn-forgot').addEventListener('click', () => {
    const email = prompt("Please enter your registered Gmail for password reset:");
    if (email) {
        alert("If this email is registered, a reset link will be sent shortly. (Logic for PHPMailer goes here)");
    }
});