<?php
require_once('DBConnection.php');
if(isset($_GET['id'])){
    // Fetching existing member data for the update process
    $qry = $conn->query("SELECT * FROM members WHERE id = '{$_GET['id']}'");
    if($qry->num_rows > 0){
        foreach($qry->fetch_array() as $k => $v){
            if(!is_numeric($k))
            $$k = $v;
        }
    }
}
?>
<div class="container-fluid">
    <form action="" id="member-form">
        <input type="hidden" name="id" value="<?php echo isset($id) ? $id : '' ?>">
        <div class="form-group mb-2">
            <label for="firstname" class="control-label">First Name</label>
            <input type="text" name="firstname" class="form-control form-control-sm rounded-0" value="<?php echo isset($firstname) ? $firstname : "" ?>" required>
        </div>
        <div class="form-group mb-2">
            <label for="lastname" class="control-label">Last Name</label>
            <input type="text" name="lastname" class="form-control form-control-sm rounded-0" value="<?php echo isset($lastname) ? $lastname : "" ?>" required>
        </div>
        <div class="form-group mb-2">
            <label for="contact" class="control-label">Contact Number</label>
            <input type="text" name="contact" class="form-control form-control-sm rounded-0" value="<?php echo isset($contact) ? $contact : "" ?>" required>
        </div>
        <div class="form-group mb-2">
            <label for="address" class="control-label">Physical Address</label>
            <textarea rows="3" name="address" class="form-control form-control-sm rounded-0" required><?php echo isset($address) ? $address : "" ?></textarea>
        </div>
    </form>
</div>
<script>
$(function(){
    $('#member-form').submit(function(e){
        e.preventDefault();
        $('.pop_msg').remove();
        var _this = $(this);
        var _el = $('<div>');
            _el.addClass('pop_msg');
        $('#uni_modal button').attr('disabled', true);
        $('#uni_modal button[type="submit"]').text('Submitting data to the system...');
        
        $.ajax({
            url: './Actions.php?a=save_member',
            data: new FormData($(this)[0]),
            cache: false,
            contentType: false,
            processData: false,
            method: 'POST',
            type: 'POST',
            dataType: 'json',
            error: err => {
                console.log(err);
                _el.addClass('alert alert-danger');
                _el.text("A system error occurred while saving the data.");
                _this.prepend(_el);
                _el.show('slow');
                $('#uni_modal button').attr('disabled', false);
                $('#uni_modal button[type="submit"]').text('Save');
            },
            success: function(resp){
                if(resp.status == 'success'){
                    _el.addClass('alert alert-success');
                    // Reloading the page to show the updated list and the new audit log entry
                    $('#uni_modal').on('hide.bs.modal', function(){
                        location.reload();
                    });
                    _this.get(0).reset();
                } else {
                    _el.addClass('alert alert-danger');
                }
                _el.text(resp.msg);
                _el.hide();
                _this.prepend(_el);
                _el.show('slow');
                $('#uni_modal button').attr('disabled', false);
                $('#uni_modal button[type="submit"]').text('Save');
            }
        });
    });
});
</script>