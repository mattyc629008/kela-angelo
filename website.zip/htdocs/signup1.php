<?php
ini_set('display_errors', 0);
error_reporting(0);
session_start();

require_once 'DBConnection.php';

// Already logged in? No need to register
if (isset($_SESSION['id'])) {
    header('Location: dashboard.php');
    exit;
}

$error   = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name     = trim($_POST['name']     ?? '');
    $email    = trim($_POST['email']    ?? '');
    $password =      $_POST['password'] ?? '';

    if (empty($name) || empty($email) || empty($password)) {
        $error = 'Please fill in all fields.';
    } elseif (strlen($password) < 6) {
        $error = 'Password must be at least 6 characters.';
    } else {
        $db = new DBConnection();

        // Check if email already exists
        $check = $db->conn->prepare("SELECT id FROM `users` WHERE `email` = ?");
        $check->bind_param("s", $email);
        $check->execute();
        $check->store_result();

        if ($check->num_rows > 0) {
            $error = 'Ang email na ito ay may account na.';
        } else {
            $hashed = password_hash($password, PASSWORD_DEFAULT);
            $stmt   = $db->conn->prepare("INSERT INTO `users` (fullname, email, password) VALUES (?, ?, ?)");
            $stmt->bind_param("sss", $name, $email, $hashed);

            if ($stmt->execute()) {
                // Audit log
                $action   = "New User Registered: " . $name;
                $log_stmt = $db->conn->prepare("INSERT INTO `logs` (`action_made`, `performed_by`) VALUES (?, ?)");
                $log_stmt->bind_param("ss", $action, $name);
                $log_stmt->execute();

                $success = 'Account created! You can now log in.';
            } else {
                $error = 'Nagka-error sa pag-save. Subukan ulit.';
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign Up | Bhea Cay Aesthetic</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;600;800&display=swap');
        body { font-family: 'Plus Jakarta Sans', sans-serif; background-color: #FDFBF9; }
        .custom-accent  { color: rgb(180, 140, 100); }
        .bg-custom-accent { background-color: rgb(180, 140, 100); }
        .border-custom-accent { border-color: rgb(180, 140, 100); }
        .ring-custom-accent { --tw-ring-color: rgba(180, 140, 100, 0.2); }
        .glass-card {
            background: rgba(255, 255, 255, 0.9);
            backdrop-filter: blur(10px);
            border: 1px solid rgba(180, 140, 100, 0.1);
        }
    </style>
</head>
<body class="min-h-screen flex items-center justify-center p-4">

    <div class="fixed inset-0 z-[-1] opacity-30"
         style="background: radial-gradient(circle at top right, rgb(180, 140, 100) 0%, transparent 45%);">
    </div>

    <div class="max-w-[420px] w-full glass-card rounded-[2.5rem] shadow-[0_25px_60px_rgba(180,140,100,0.15)] p-10 relative overflow-hidden">

        <div class="absolute -bottom-10 -left-10 w-32 h-32 bg-custom-accent opacity-10 rounded-full blur-3xl"></div>

        <div class="text-center mb-10">
            <div class="w-16 h-16 bg-[#fcf9f5] rounded-2xl flex items-center justify-center mx-auto mb-5 shadow-xl shadow-[#b06d25]/20 -rotate-3 transition-transform hover:rotate-0 duration-500">
                <i data-lucide="sparkles" class="w-8 h-8 custom-accent"></i>
            </div>
            <h2 class="text-2xl font-extrabold text-[#3D3228] tracking-tight">Bhea Cay</h2>
            <p class="text-[10px] custom-accent font-black uppercase tracking-[0.3em] mt-2">Create Your Account</p>
        </div>

        <?php if (!empty($error)): ?>
        <div class="mb-5 px-4 py-3 rounded-xl text-sm text-center font-semibold bg-red-50 text-red-600">
            ✗ <?= htmlspecialchars($error) ?>
        </div>
        <?php endif; ?>

        <?php if (!empty($success)): ?>
        <div class="mb-5 px-4 py-3 rounded-xl text-sm text-center font-semibold bg-green-50 text-green-700">
            ✓ <?= htmlspecialchars($success) ?>
            <div class="mt-2">
                <a href="login.php" class="underline font-bold">Pumunta sa Login →</a>
            </div>
        </div>
        <?php endif; ?>

        <?php if (empty($success)): ?>
        <form method="POST" class="space-y-5">

            <div class="group">
                <label class="block text-[10px] font-bold text-[#3D3228] uppercase tracking-[0.15em] mb-2 ml-1 opacity-60 group-focus-within:opacity-100 transition-opacity">Username</label>
                <div class="relative">
                    <i data-lucide="user" class="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 custom-accent"></i>
                    <input type="text" name="name" required
                           value="<?= htmlspecialchars($_POST['name'] ?? '') ?>"
                           class="w-full pl-12 pr-4 py-3.5 bg-white border border-gray-100 rounded-2xl text-sm focus:outline-none focus:ring-4 ring-custom-accent border-custom-accent transition-all placeholder:text-gray-300"
                           placeholder="Juan Dela Cruz">
                </div>
            </div>

            <div class="group">
                <label class="block text-[10px] font-bold text-[#3D3228] uppercase tracking-[0.15em] mb-2 ml-1 opacity-60">Email Address</label>
                <div class="relative">
                    <i data-lucide="mail" class="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 custom-accent"></i>
                    <input type="email" name="email" required
                           value="<?= htmlspecialchars($_POST['email'] ?? '') ?>"
                           class="w-full pl-12 pr-4 py-3.5 bg-white border border-gray-100 rounded-2xl text-sm focus:outline-none focus:ring-4 ring-custom-accent border-custom-accent transition-all"
                           placeholder="email@bheacay.com">
                </div>
            </div>

            <div class="group">
                <label class="block text-[10px] font-bold text-[#3D3228] uppercase tracking-[0.15em] mb-2 ml-1 opacity-60">Security Password</label>
                <div class="relative">
                    <i data-lucide="lock" class="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 custom-accent"></i>
                    <input type="password" name="password" required
                           class="w-full pl-12 pr-4 py-3.5 bg-white border border-gray-100 rounded-2xl text-sm focus:outline-none focus:ring-4 ring-custom-accent border-custom-accent transition-all"
                           placeholder="••••••••">
                </div>
            </div>

            <button type="submit"
                    class="w-full py-4 bg-custom-accent text-white rounded-2xl font-bold text-[11px] uppercase tracking-[0.25em] hover:bg-[#3D3228] hover:shadow-2xl hover:shadow-[#B48C64]/20 transform active:scale-[0.96] transition-all flex items-center justify-center gap-3 mt-6">
                Register Account
                <i data-lucide="arrow-right" class="w-4 h-4"></i>
            </button>

            <div class="pt-4 text-center">
                <p class="text-[11px] text-[#7A6B5D]">
                    May account na?
                    <a href="login.php" class="custom-accent font-bold hover:underline underline-offset-4 decoration-2">Mag-login dito</a>
                </p>
            </div>

        </form>
        <?php endif; ?>
    </div>

    <script>lucide.createIcons();</script>
</body>
</html>