<?php
/**
 * includes/auth_api.php
 *
 * FIXES applied:
 *  1. include path changed from 'db_connect.php' → '../DBConnection.php'
 *     (this file lives in includes/, DBConnection.php is one level up in root)
 *  2. Removed wrong method real_escape_with_mysqli() — mysqli has no such method.
 *     Now uses $db->conn->real_escape_string() which is correct.
 *  3. Uses $db object (DBConnection instance) instead of bare $conn variable.
 *  4. ini_set + ob_start guard added so any stray PHP warning never corrupts JSON.
 *  5. Duplicate-email error now detected via $stmt->errno === 1062 (unique constraint).
 */

ini_set('display_errors', 0);
error_reporting(0);
ob_start();

header('Content-Type: application/json; charset=utf-8');

try {
    require_once __DIR__ . '/DBConnection.php';
    $db = new DBConnection();
} catch (Throwable $e) {
    ob_end_clean();
    echo json_encode(['success' => false, 'message' => 'DB connection failed: ' . $e->getMessage()]);
    exit;
}

// Only handle POST requests
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    ob_end_clean();
    echo json_encode(['success' => false, 'message' => 'Invalid request method.']);
    exit;
}

// Read JSON body sent by signup1.js
$data = json_decode(file_get_contents('php://input'), true);

if (empty($data['name']) || empty($data['email']) || empty($data['password'])) {
    ob_end_clean();
    echo json_encode(['success' => false, 'message' => 'All fields are required.']);
    exit;
}

// FIXED: real_escape_with_mysqli() does not exist — use real_escape_string()
$name  = $db->conn->real_escape_string(trim($data['name']));
$email = $db->conn->real_escape_string(trim($data['email']));

// Never store plain-text passwords
$password = password_hash($data['password'], PASSWORD_DEFAULT);

// 1. Insert user
$sql  = "INSERT INTO users (fullname, email, password) VALUES (?, ?, ?)";
$stmt = $db->conn->prepare($sql);

if (!$stmt) {
    ob_end_clean();
    echo json_encode(['success' => false, 'message' => 'DB prepare error: ' . $db->conn->error]);
    exit;
}

$stmt->bind_param('sss', $name, $email, $password);

if ($stmt->execute()) {
    // 2. Audit trail log
    $log_sql  = "INSERT INTO logs (user_id, action_made) VALUES (?, ?)";
    $log_stmt = $db->conn->prepare($log_sql);

    if ($log_stmt) {
        $new_user_id = $db->conn->insert_id;
        $log_action  = "New User Registered: {$name}";
        $log_stmt->bind_param('is', $new_user_id, $log_action);
        $log_stmt->execute();
    }

    ob_end_clean();
    echo json_encode(['success' => true, 'message' => 'Registration successful!']);
} else {
    // errno 1062 = Duplicate entry (email already exists)
    $msg = ($stmt->errno === 1062)
        ? 'Email already exists. Please use a different email.'
        : 'Registration failed: ' . $stmt->error;

    ob_end_clean();
    echo json_encode(['success' => false, 'message' => $msg]);
}
?>