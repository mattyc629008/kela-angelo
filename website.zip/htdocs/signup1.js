/**
 * signup1.js
 *
 * FIXES applied:
 *  1. Fetch URL corrected to 'includes/auth_api.php' — the file lives in
 *     includes/, NOT at root. The old URL 'signup1.php?action=register'
 *     had no register handler and was returning HTML, breaking JSON.parse().
 *  2. Kept Content-Type: application/json so auth_api.php reads php://input correctly.
 *  3. Added loading / disabled state on the submit button to prevent double submits.
 */

document.addEventListener('DOMContentLoaded', () => {
    // Initialise Lucide icons if the library is loaded on this page
    if (typeof lucide !== 'undefined') lucide.createIcons();

    const signupForm = document.getElementById('signup-form');
    const msgBox     = document.getElementById('signup-msg'); // optional feedback div
    if (!signupForm) return;

    signupForm.addEventListener('submit', async (e) => {
        e.preventDefault();

        const nameEl     = document.getElementById('reg-name');
        const emailEl    = document.getElementById('reg-email');
        const passwordEl = document.getElementById('reg-password');
        const submitBtn  = signupForm.querySelector('[type="submit"]');

        const data = {
            name:     nameEl?.value.trim()     ?? '',
            email:    emailEl?.value.trim()    ?? '',
            password: passwordEl?.value        ?? ''
        };

        if (!data.name || !data.email || !data.password) {
            showMsg('Please fill in all fields.', 'error');
            return;
        }

        // Loading state
        const originalHTML = submitBtn?.innerHTML ?? 'Register';
        if (submitBtn) {
            submitBtn.disabled   = true;
            submitBtn.innerHTML  = '<span class="animate-pulse italic">Registering…</span>';
        }

        try {
            // FIXED: was 'signup1.php?action=register' — no handler there.
            // auth_api.php is inside the includes/ folder, one level down from root.
           const res = await fetch('auth_api.php', {
                method:  'POST',
                headers: { 'Content-Type': 'application/json' },
                body:    JSON.stringify(data)
            });

            // Guard: if the server returned HTML instead of JSON, surface a clear error
            const contentType = res.headers.get('Content-Type') ?? '';
            if (!contentType.includes('application/json')) {
                const raw = await res.text();
                console.error('Non-JSON response from auth_api.php:', raw);
                throw new Error('Server returned non-JSON. Check PHP error logs.');
            }

            const result = await res.json();

            if (result.success) {
                showMsg('✓ Registration successful! Redirecting to login…', 'success');
                setTimeout(() => { window.location.href = 'login.php'; }, 1500);
            } else {
                showMsg('✗ ' + (result.message ?? 'Registration failed.'), 'error');
                if (submitBtn) {
                    submitBtn.disabled  = false;
                    submitBtn.innerHTML = originalHTML;
                    if (typeof lucide !== 'undefined') lucide.createIcons();
                }
            }

        } catch (err) {
            console.error('Signup error:', err);
            showMsg('✗ Connection error. Is the server running? ' + err.message, 'error');
            if (submitBtn) {
                submitBtn.disabled  = false;
                submitBtn.innerHTML = originalHTML;
                if (typeof lucide !== 'undefined') lucide.createIcons();
            }
        }
    });

    /**
     * Show a feedback message.
     * Looks for a <div id="signup-msg"> on the page; falls back to alert().
     */
    function showMsg(text, type /* 'success' | 'error' */) {
        if (msgBox) {
            msgBox.textContent = text;
            msgBox.className = type === 'success'
                ? 'mb-4 px-4 py-3 rounded-xl text-sm text-center font-semibold bg-green-50 text-green-700'
                : 'mb-4 px-4 py-3 rounded-xl text-sm text-center font-semibold bg-red-50 text-red-600';
            msgBox.classList.remove('hidden');
        } else {
            alert(text);
        }
    }
});