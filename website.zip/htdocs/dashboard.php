<?php
/**
 * Bhea Cay Aesthetic Inventory System
 * Pinagsamang Dashboard, FIFO Logic, at Audit Trail
 */

session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Redirect to login if not logged in
if (!isset($_SESSION['id'])) {
    header('Location: login.php');
    exit;
}

$current_user = $_SESSION['fullname'] ?? $_SESSION['email'] ?? 'Admin';

// --- DATABASE CONNECTION ---
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "bhea_cay_db";

$conn = new mysqli($servername, $username, $password);
if ($conn->connect_error) { die("Connection failed: " . $conn->connect_error); }

$conn->query("CREATE DATABASE IF NOT EXISTS $dbname");
$conn->select_db($dbname);

// Database Tables Initialization
$conn->query("CREATE TABLE IF NOT EXISTS inventory (
    id INT AUTO_INCREMENT PRIMARY KEY,
    product_name VARCHAR(255) NOT NULL,
    category VARCHAR(100),
    quantity INT DEFAULT 0,
    unit_price DECIMAL(10, 2),
    expiry_date DATE,
    supplier VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)");

$conn->query("CREATE TABLE IF NOT EXISTS logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    action_made TEXT NOT NULL,
    performed_by VARCHAR(255),
    date_created TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)");

// --- API ACTIONS ---
if (isset($_GET['action'])) {
    header("Content-Type: application/json");
    
    if ($_GET['action'] === 'fetch') {
        $result = $conn->query("SELECT *, id as __backendId FROM inventory ORDER BY created_at ASC");
        echo json_encode($result->fetch_all(MYSQLI_ASSOC));
        exit;
    } 

    if ($_GET['action'] === 'add') {
        $data = json_decode(file_get_contents("php://input"), true);
        $stmt = $conn->prepare("INSERT INTO inventory (product_name, category, quantity, unit_price, expiry_date, supplier) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("ssidss", $data['name'], $data['category'], $data['quantity'], $data['price'], $data['expiry'], $data['supplier']);
        if ($stmt->execute()) {
            $log = "Added Product: " . $data['name'];
            $stmt_log = $conn->prepare("INSERT INTO logs (action_made, performed_by) VALUES (?, ?)");
            $stmt_log->bind_param("ss", $log, $current_user);
            $stmt_log->execute();
            echo json_encode(["status" => "success"]);
        }
        exit;
    }

    if ($_GET['action'] === 'update_stock' && isset($_GET['id']) && isset($_GET['change'])) {
        $product_id = intval($_GET['id']);
        $change = intval($_GET['change']); 
        $product_res = $conn->query("SELECT product_name FROM inventory WHERE id = $product_id");
        
        if ($product_data = $product_res->fetch_assoc()) {
            $p_name = $product_data['product_name'];
            $stmt = ($change > 0) 
                ? $conn->prepare("UPDATE inventory SET quantity = quantity + ? WHERE id = ?")
                : $conn->prepare("UPDATE inventory SET quantity = GREATEST(0, quantity - ?) WHERE id = ?");
            
            $abs_change = abs($change);
            $stmt->bind_param("ii", $abs_change, $product_id);
            if ($stmt->execute()) {
                $type = ($change > 0) ? "Stock In" : "Stock Out";
                $log_msg = "$type: $p_name (Amount: $abs_change)";
                $stmt_log = $conn->prepare("INSERT INTO logs (action_made, performed_by) VALUES (?, ?)");
                $stmt_log->bind_param("ss", $log_msg, $current_user);
                $stmt_log->execute();
            }
            echo json_encode(["status" => "success"]);
        }
        exit;
    }

    if ($_GET['action'] === 'delete' && isset($_GET['id'])) {
        $id = intval($_GET['id']);
        $res = $conn->query("SELECT product_name FROM inventory WHERE id = $id");
        $p = $res->fetch_assoc();
        $p_name = $p['product_name'] ?? "Unknown";

        if ($conn->query("DELETE FROM inventory WHERE id = $id")) {
            $log_msg = "Deleted Product: $p_name";
            $stmt_log = $conn->prepare("INSERT INTO logs (action_made, performed_by) VALUES (?, ?)");
            $stmt_log->bind_param("ss", $log_msg, $current_user);
            $stmt_log->execute();
        }
        echo json_encode(["status" => "success"]);
        exit;
    }

    if ($_GET['action'] === 'fetch_logs') {
        $result = $conn->query("SELECT * FROM logs ORDER BY date_created DESC LIMIT 100");
        echo json_encode($result->fetch_all(MYSQLI_ASSOC));
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="en" class="h-full">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bhea Cay Aesthetic Inventory</title>
    <script src="https://cdn.tailwindcss.com/3.4.17"></script>
    <script src="https://cdn.jsdelivr.net/npm/lucide@0.263.0/dist/umd/lucide.min.js"></script>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Poppins', sans-serif; background-color: #FAF7F4; color: #3D3228; }
        .tab-active { border-bottom: 3px solid #B48C64; color: #B48C64; font-weight: 600; }
        .card { background: white; border: 1px solid #E8E0D8; border-radius: 1rem; box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.05); }
        .input-field { width: 100%; padding: 0.6rem 1rem; border-radius: 0.5rem; border: 1px solid #E8E0D8; background: #FAF7F4; outline-color: #B48C64; font-size: 0.875rem; }
    </style>
</head>
<body class="h-full">

    <nav class="fixed top-0 w-full z-50 bg-[#FAF7F4]/80 backdrop-blur-md border-b border-[#E8E0D8]">
        <div class="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">

            <!-- Left: Logo -->
            <div class="flex items-center gap-3">
                <div class="w-10 h-10 rounded-xl bg-[#B48C64] flex items-center justify-center">
                    <i data-lucide="sparkles" class="text-white w-6 h-6"></i>
                </div>
                <div>
                    <h1 class="font-bold text-lg leading-none">Bhea Cay Aesthetic</h1>
                    <p class="text-xs text-[#7A6B5D]">Inventory Management System</p>
                </div>
            </div>

            <!-- Right: User info + Logout -->
            <div class="flex items-center gap-4">
                <!-- Logged-in user display -->
                <div class="hidden sm:flex items-center gap-2 text-sm text-[#7A6B5D]">
                    <div class="w-7 h-7 rounded-full bg-[#E8E0D8] flex items-center justify-center">
                        <i data-lucide="user" class="w-4 h-4 text-[#B48C64]"></i>
                    </div>
                    <span class="font-medium text-[#3D3228]"><?= htmlspecialchars($current_user) ?></span>
                </div>

                <!-- Logout button -->
                <a href="logout.php"
                   onclick="return confirm('Are you sure you want to logout?')"
                   class="flex items-center gap-2 px-4 py-2 rounded-xl border border-[#E8E0D8] bg-white text-sm font-semibold text-[#3D3228] hover:bg-red-50 hover:border-red-200 hover:text-red-600 transition-all duration-200">
                    <i data-lucide="log-out" class="w-4 h-4"></i>
                    <span class="hidden sm:inline">Logout</span>
                </a>
            </div>

        </div>
    </nav>

    <main class="pt-28 pb-12 px-6 max-w-7xl mx-auto">
        <div class="flex flex-col md:flex-row justify-between items-end mb-8 gap-4">
            <div>
                <h2 class="text-3xl font-bold">Dashboard</h2>
                <p class="text-[#7A6B5D]">Manage your FIFO stock and track every movement.</p>
            </div>
            <button onclick="location.reload()" class="p-2 border rounded-lg bg-white hover:bg-gray-50"><i data-lucide="refresh-cw" class="w-5 h-5 text-[#B48C64]"></i></button>
        </div>

        <div class="flex gap-8 border-b mb-8 border-[#E8E0D8]">
            <button id="tab-view" onclick="showView()" class="pb-3 text-sm tab-active">View Inventory</button>
            <button id="tab-add" onclick="showAdd()" class="pb-3 text-sm text-[#7A6B5D]">Add Product</button>
            <button id="tab-logs" onclick="showLogs()" class="pb-3 text-sm text-[#7A6B5D]">Audit Trail</button>
        </div>

        <div id="view-section" class="space-y-6">
            <div class="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div class="card p-5"><p class="text-[10px] font-bold text-[#7A6B5D] uppercase">Total Products</p><p id="stat-total" class="text-2xl font-bold text-[#B48C64]">0</p></div>
                <div class="card p-5"><p class="text-[10px] font-bold text-[#7A6B5D] uppercase">Low Stock</p><p id="stat-low" class="text-2xl font-bold text-red-500">0</p></div>
                <div class="card p-5"><p class="text-[10px] font-bold text-[#7A6B5D] uppercase">Expiring Soon</p><p id="stat-expiry" class="text-2xl font-bold text-orange-400">0</p></div>
                <div class="card p-5"><p class="text-[10px] font-bold text-[#7A6B5D] uppercase">Inventory Value</p><p id="stat-value" class="text-2xl font-bold text-[#B48C64]">₱0</p></div>
            </div>

            <div class="card overflow-hidden">
                <div class="p-4 border-b border-[#E8E0D8] bg-gray-50/50 flex flex-col md:flex-row gap-4">
                    <div class="relative flex-1">
                        <i data-lucide="search" class="absolute left-3 top-2.5 w-4 h-4 text-gray-400"></i>
                        <input id="search-input" type="text" placeholder="Search product name..." class="w-full pl-10 pr-4 py-2 rounded-lg border text-sm outline-none">
                    </div>
                    <select id="category-filter" class="px-4 py-2 rounded-lg border text-sm outline-none bg-white">
                        <option value="">All Categories</option>
                        <option>Serums & Oils</option>
                        <option>Moisturizers</option>
                        <option>Treatments</option>
                        <option>Supplements</option>
                        <option>Equipment</option>
                    </select>
                </div>
                <div id="inventory-list" class="divide-y divide-[#E8E0D8]"></div>
            </div>
        </div>

        <div id="add-section" class="hidden">
            <div class="max-w-2xl mx-auto card p-8">
                <h3 id="form-title" class="text-xl font-bold mb-6">Add New Product</h3>
                <form id="product-form" class="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div class="md:col-span-2"><label class="text-xs font-bold">PRODUCT NAME</label><input id="form-name" type="text" required class="input-field"></div>
                    <div><label class="text-xs font-bold">CATEGORY</label>
                        <select id="form-category" required class="input-field">
                            <option value="">Select Category</option>
                            <option>Serums & Oils</option><option>Moisturizers</option><option>Treatments</option><option>Supplements</option><option>Equipment</option>
                        </select>
                    </div>
                    <div><label class="text-xs font-bold">QUANTITY</label><input id="form-qty" type="number" required class="input-field"></div>
                    <div><label class="text-xs font-bold">UNIT PRICE (₱)</label><input id="form-price" type="number" step="0.01" required class="input-field"></div>
                    <div><label class="text-xs font-bold">EXPIRY DATE</label><input id="form-expiry" type="date" class="input-field"></div>
                    <div class="md:col-span-2"><label class="text-xs font-bold">SUPPLIER</label><input id="form-supplier" type="text" class="input-field"></div>
                    <div class="md:col-span-2 flex gap-3"><button type="submit" id="submit-btn" class="flex-1 bg-[#B48C64] text-white py-3 rounded-lg font-bold">Save Product</button><button type="button" id="form-cancel" class="px-6 py-3 border rounded-lg">Cancel</button></div>
                </form>
            </div>
        </div>

        <div id="logs-section" class="hidden">
            <div class="card overflow-hidden">
                <div class="p-6 border-b flex justify-between items-center">
                    <h3 class="font-bold flex items-center gap-2">
                        Audit Trail 
                        <span class="flex h-2 w-2 rounded-full bg-green-500 animate-pulse"></span> 
                        <span class="text-[10px] text-gray-400 font-normal uppercase tracking-widest">Live Updates</span>
                    </h3>
                    <button onclick="loadAuditLogs()" class="p-2 hover:bg-gray-100 rounded-full transition-colors">
                        <i data-lucide="refresh-cw" class="w-4 h-4 text-[#B48C64]"></i>
                    </button>
                </div>
                <div class="overflow-x-auto">
                    <table class="w-full text-left text-sm">
                        <thead class="bg-[#FAF7F4] border-b">
                            <tr>
                                <th class="px-6 py-4 font-bold text-gray-500 uppercase text-[10px]">Date & Time</th>
                                <th class="px-6 py-4 font-bold text-gray-500 uppercase text-[10px]">Transaction Details</th>
                                <th class="px-6 py-4 font-bold text-gray-500 uppercase text-[10px]">Performed By</th>
                            </tr>
                        </thead>
                        <tbody id="logs-list"></tbody>
                    </table>
                </div>
            </div>
        </div>
    </main>

    <script src="dashboard_inventory.js"></script>
</body>
</html>