<?php
session_start();

if (isset($_SESSION['id'])) {
    require_once 'DBConnection.php';
    $db          = new DBConnection();
    $performed_by = $_SESSION['fullname'] ?? $_SESSION['email'] ?? 'Unknown';
    $action       = "User logged out from the system.";
    $log          = $db->conn->prepare("INSERT INTO `logs` (`action_made`, `performed_by`) VALUES (?, ?)");
    $log->bind_param("ss", $action, $performed_by);
    $log->execute();
}

session_unset();
session_destroy();

header('Location: index.php');
exit;
?>