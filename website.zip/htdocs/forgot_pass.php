<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forgot Password | Bhea Cay Aesthetic</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600;800&display=swap');
        body { font-family: 'Plus Jakarta Sans', sans-serif; background-color: #FDFBF9; }
        .accent-color { color: #B48C64; }
        .bg-accent { background-color: #B48C64; }
        .border-accent { border-color: #B48C64; }
    </style>
</head>
<body class="min-h-screen flex items-center justify-center p-4 bg-[radial-gradient(circle_at_top_right,_#B48C6410_0%,_transparent_40%)]">

    <div class="max-w-[400px] w-full bg-white rounded-[2.5rem] shadow-[0_20px_50px_rgba(180,140,100,0.1)] border border-[#B48C6410] p-10 relative overflow-hidden text-center">
        
        <a href="login.php" class="absolute left-8 top-8 p-2 rounded-full hover:bg-[#FDFBF9] transition-colors group">
            <i data-lucide="arrow-left" class="w-5 h-5 text-[#7A6B5D] group-hover:text-[#B48C64]"></i>
        </a>

        <div class="mb-10 mt-4">
            <div class="w-16 h-16 bg-[#FDFBF9] border border-[#E8E2DA] rounded-2xl flex items-center justify-center mx-auto mb-5 shadow-sm rotate-6 transition-transform hover:rotate-0 duration-500">
                <i data-lucide="fingerprint" class="w-8 h-8 accent-color"></i>
            </div>
            <h2 class="text-2xl font-extrabold text-[#3D3228] tracking-tight">Nakalimutan ang Password?</h2>
            <p class="text-[11px] text-[#7A6B5D] mt-3 leading-relaxed px-4">
                Huwag mag-alala. I-type ang iyong email sa ibaba at padadalhan ka namin ng instructions para ma-reset ito.
            </p>
        </div>

        <form id="forgot-form" class="space-y-6">
            <div class="group text-left">
                <label class="block text-[10px] font-bold text-[#3D3228] uppercase tracking-widest mb-2 ml-1 opacity-60">Registered Email</label>
                <div class="relative">
                    <i data-lucide="mail" class="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 accent-color"></i>
                    <input type="email" name="email" required
                        class="w-full pl-12 pr-4 py-3.5 bg-[#FDFBF9] border border-[#E8E2DA] rounded-2xl text-sm focus:outline-none focus:ring-4 focus:ring-[#B48C6415] focus:border-accent transition-all placeholder:text-gray-300"
                        placeholder="halimbawa@email.com">
                </div>
            </div>

            <button type="submit" 
                class="w-full py-4 bg-[#B48C64] text-white rounded-2xl font-bold text-[11px] uppercase tracking-[0.2em] hover:bg-[#3D3228] hover:shadow-xl hover:shadow-[#B48C6430] transform active:scale-95 transition-all flex items-center justify-center gap-3">
                Ipadala ang Reset Link
                <i data-lucide="send" class="w-4 h-4"></i>
            </button>

            <p class="text-[11px] text-[#7A6B5D] pt-4 border-t border-gray-50">
                Naalala mo na? 
                <a href="login.php" class="accent-color font-bold hover:underline">Bumalik sa Login</a>
            </p>
        </form>
    </div>

    <script>
        lucide.createIcons();

        // Simple UX Feedback
        document.getElementById('forgot-form').onsubmit = function(e) {
            e.preventDefault();
            const btn = e.target.querySelector('button');
            btn.innerHTML = '<i data-lucide="check-circle" class="w-4 h-4"></i> Link Sent!';
            btn.classList.replace('bg-[#B48C64]', 'bg-green-600');
            lucide.createIcons();
            
            setTimeout(() => {
                alert("Tingnan ang iyong email para sa reset link.");
            }, 500);
        };
    </script>
</body>
</html>