<?php
ini_set('display_errors', 0);
error_reporting(0);
session_start();

require_once 'DBConnection.php';

// Already logged in? Go straight to dashboard
if (isset($_SESSION['id'])) {
    header('Location: dashboard.php');
    exit;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email    = trim($_POST['email']    ?? '');
    $password =      $_POST['password'] ?? '';

    if (empty($email) || empty($password)) {
        $error = 'Email and password are required.';
    } else {
        $db   = new DBConnection();
        $stmt = $db->conn->prepare("SELECT * FROM `users` WHERE `email` = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $user = $stmt->get_result()->fetch_assoc();

        if ($user && password_verify($password, $user['password'])) {
            foreach ($user as $key => $value) {
                if (!is_numeric($key)) $_SESSION[$key] = $value;
            }

            $performed_by = $user['fullname'] ?? $email;
            $action       = "User logged into the system.";
            $log          = $db->conn->prepare("INSERT INTO `logs` (`action_made`, `performed_by`) VALUES (?, ?)");
            $log->bind_param("ss", $action, $performed_by);
            $log->execute();

            header('Location: dashboard.php');
            exit;
        } else {
            $error = 'Invalid email or password.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login | Bhea Cay Aesthetic</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;600;800&display=swap');
        body { font-family: 'Plus Jakarta Sans', sans-serif; background-color: #FDFBF9; }
        .custom-gold  { color: rgb(180, 140, 100); }
        .bg-custom-gold { background-color: rgb(180, 140, 100); }
        .glass-card {
            background: rgba(255,255,255,0.9);
            backdrop-filter: blur(12px);
            border: 1px solid rgba(180,140,100,0.1);
        }
        .input-focus:focus {
            outline: none;
            border-color: rgb(180,140,100);
            box-shadow: 0 0 0 4px rgba(180,140,100,0.1);
        }
    </style>
</head>
<body class="min-h-screen flex items-center justify-center p-4">

    <div class="fixed inset-0 z-[-1] opacity-20"
         style="background: radial-gradient(circle at bottom left, rgb(180,140,100) 0%, transparent 50%);">
    </div>

    <div class="max-w-[400px] w-full glass-card rounded-[2.5rem] shadow-[0_30px_70px_rgba(61,50,40,0.12)] p-10 relative overflow-hidden">

        <div class="absolute -top-12 -left-12 w-32 h-32 bg-custom-gold opacity-5 rounded-full blur-3xl"></div>

        <div class="text-center mb-10">
            <div class="w-16 h-16 bg-[#ededed] rounded-2xl flex items-center justify-center mx-auto mb-5 shadow-xl shadow-[#3D3228]/20 rotate-3 transition-transform hover:rotate-0 duration-500">
                <i data-lucide="key-round" class="w-8 h-8 custom-gold"></i>
            </div>
            <h2 class="text-2xl font-extrabold text-[#3D3228] tracking-tight">Welcome Back</h2>
            <p class="text-[10px] custom-gold font-black uppercase tracking-[0.3em] mt-2">Bhea Cay Inventory Login</p>
        </div>

        <?php if (!empty($error)): ?>
        <div class="mb-4 px-4 py-3 rounded-xl text-sm text-center font-semibold bg-red-50 text-red-600">
            ✗ <?= htmlspecialchars($error) ?>
        </div>
        <?php endif; ?>

        <form method="POST" class="space-y-6">

            <div class="group">
                <label class="block text-[10px] font-bold text-[#3D3228] uppercase tracking-[0.15em] mb-2 ml-1 opacity-60 group-focus-within:opacity-100 transition-opacity">
                    Email Address
                </label>
                <div class="relative">
                    <i data-lucide="mail" class="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 custom-gold"></i>
                    <input type="email" name="email" required
                           value="<?= htmlspecialchars($_POST['email'] ?? '') ?>"
                           class="w-full pl-12 pr-4 py-3.5 bg-white/50 border border-gray-100 rounded-2xl text-sm input-focus transition-all placeholder:text-gray-300"
                           placeholder="email@bheacay.com">
                </div>
            </div>

            <div class="group">
                <div class="flex justify-between items-center mb-2 px-1">
                    <label class="text-[10px] font-bold text-[#3D3228] uppercase tracking-[0.15em] opacity-60">Password</label>
                    <a href="forgot_pass.php" class="text-[9px] custom-gold font-bold uppercase tracking-wider hover:underline">Forgot?</a>
                </div>
                <div class="relative">
                    <i data-lucide="shield-check" class="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 custom-gold"></i>
                    <input type="password" name="password" required
                           class="w-full pl-12 pr-4 py-3.5 bg-white/50 border border-gray-100 rounded-2xl text-sm input-focus transition-all placeholder:text-gray-300"
                           placeholder="••••••••">
                </div>
            </div>

            <button type="submit"
                    class="w-full py-4 bg-[#3D3228] text-[#FDFBF9] rounded-2xl font-bold text-[11px] uppercase tracking-[0.25em] hover:bg-custom-gold hover:shadow-xl hover:shadow-custom-gold/30 transform active:scale-[0.96] transition-all flex items-center justify-center gap-3 mt-4">
                Sign In
                <i data-lucide="arrow-right-circle" class="w-4 h-4"></i>
            </button>

            <div class="pt-6 text-center border-t border-gray-50">
                <p class="text-[11px] text-[#7A6B5D]">
                    Wala pang account?
                    <a href="signup1.php" class="custom-gold font-bold hover:underline underline-offset-4 decoration-2">Mag-register dito</a>
                </p>
            </div>

        </form>
    </div>

    <script>lucide.createIcons();</script>
</body>
</html>