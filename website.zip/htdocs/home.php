<?php 
/**
 * Ang home.php ay ang interface para sa pagpapakita ng listahan ng mga miyembro.
 * Ito ay konektado sa DBConnection para sa pagkuha ng datos.
 */
require_once('./DBConnection.php'); 
?>
<div class="container py-5">
    <div class="d-flex w-100 align-items-center mb-3">
        <h3 class="col-auto flex-grow-1"><b>Members List</b></h3>
        <button class="btn btn-sm btn-primary rounded-0" id="add_new">
            <i class="fa fa-plus"></i> Add New Member
        </button>
    </div>
    <div class="card shadow-sm">
        <div class="card-body">
            <table class="table table-bordered table-striped table-hover" id="member-list">
                <thead>
                    <tr>
                        <th class="py-1 px-2 text-center">#</th>
                        <th class="py-1 px-2">First Name</th>
                        <th class="py-1 px-2">Last Name</th>
                        <th class="py-1 px-2">Contact Number</th>
                        <th class="py-1 px-2">Address</th>
                        <th class="py-1 px-2 text-center">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    /**
                     * Pagkuha ng mga miyembro mula sa database 
                     * na naka-ayos base sa alpabeto.
                     */
                    $qry = $conn->query("SELECT * FROM members ORDER BY firstname ASC, lastname ASC");
                    $i = 1;
                    if($qry->num_rows > 0):
                        while($row = $qry->fetch_assoc()):
                    ?>
                    <tr>
                        <td class="py-1 px-2 text-center"><?php echo $i++ ?></td>
                        <td class="py-1 px-2"><?php echo $row['firstname'] ?></td>
                        <td class="py-1 px-2"><?php echo $row['lastname'] ?></td>
                        <td class="py-1 px-2"><?php echo $row['contact'] ?></td>
                        <td class="py-1 px-2"><?php echo $row['address'] ?></td>
                        <td class="py-1 px-2 text-center">
                            <div class="dropdown">
                                <button class="btn btn-primary btn-sm dropdown-toggle rounded-0 py-0" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                                    Options
                                </button>
                                <ul class="dropdown-menu">
                                    <li><a class="dropdown-item view_data" href="javascript:void(0)" data-id="<?php echo $row['id'] ?>">View Information</a></li>
                                    <li><a class="dropdown-item edit_data" href="javascript:void(0)" data-id="<?php echo $row['id'] ?>">Edit Details</a></li>
                                    <li><a class="dropdown-item delete_data" href="javascript:void(0)" data-id="<?php echo $row['id'] ?>" data-name="<?php echo $row['firstname'].' '.$row['lastname'] ?>">Delete Record</a></li>
                                </ul>
                            </div>
                        </td>
                    </tr>
                    <?php 
                        endwhile; 
                    else:
                    ?>
                    <tr>
                        <th class="text-center" colspan="6">No data is currently available to display.</th>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script>
    $(function(){
        /**
         * Binubuksan ang modal para sa pagpaparehistro ng bagong miyembro.
         */
        $('#add_new').click(function(){
            uni_modal('New Member Registration', "manage_member.php");
        })

        /**
         * Binubuksan ang modal para sa pag-update ng impormasyon.
         */
        $('.edit_data').click(function(){
            uni_modal('Update Member Details', "manage_member.php?id=" + $(this).attr('data-id'));
        })

        /**
         * Ginagamit ang JavaScript confirm upang masiguro ang pagbura ng record.
         */
        $('.delete_data').click(function(){
            var id = $(this).attr('data-id');
            var name = $(this).attr('data-name');
            if(confirm("Are you sure you want to remove " + name + " from the list?")){
                delete_data(id);
            }
        })

        /**
         * Binubuksan ang modal para makita ang kumpletong impormasyon.
         */
        $('.view_data').click(function(){
            uni_modal('View Member Information', "view_member.php?id=" + $(this).attr('data-id'));
        })

        /**
         * Inisyalisasyon ng DataTables para sa mabilis na paghahanap.
         */
        if($('#member-list').length > 0){
            $('#member-list').DataTable({
                columnDefs: [{ orderable: false, targets: [5] }],
                language: {
                    emptyTable: "No members are currently registered."
                }
            });
        }
    })

    /**
     * Ang function na ito ay nagpapadala ng request sa Actions.php 
     * upang burahin ang miyembro mula sa database.
     */
    function delete_data($id){
        $.ajax({
            url: './Actions.php?a=delete_member',
            method: 'POST',
            data: {id: $id},
            dataType: 'JSON',
            error: err => {
                console.log(err);
                alert("An error occurred during the deletion process.");
            },
            success: function(resp){
                if(resp.status == 'success'){
                    location.reload();
                } else {
                    alert("The system was unable to delete the record.");
                }
            }
        })
    }
</script>