/**
 * BHEA CAY AESTHETIC - INVENTORY SYSTEM (LIVE SYNC VERSION)
 */

let allProducts = [];
let searchTimeout = null;
let auditInterval = null; 

// --- NAVIGATION & TAB CONTROL ---

window.showView = function() {
    stopAuditRefresh(); 
    document.getElementById('view-section').classList.remove('hidden');
    document.getElementById('add-section').classList.add('hidden');
    document.getElementById('logs-section').classList.add('hidden');
    
    document.getElementById('tab-view').classList.add('tab-active');
    document.getElementById('tab-add').classList.remove('tab-active');
    document.getElementById('tab-logs').classList.remove('tab-active');
    resetForm();
};

window.showAdd = function() {
    stopAuditRefresh(); 
    document.getElementById('view-section').classList.add('hidden');
    document.getElementById('add-section').classList.remove('hidden');
    document.getElementById('logs-section').classList.add('hidden');
    
    document.getElementById('tab-add').classList.add('tab-active');
    document.getElementById('tab-view').classList.remove('tab-active');
    document.getElementById('tab-logs').classList.remove('tab-active');
};

window.showLogs = function() {
    document.getElementById('view-section').classList.add('hidden');
    document.getElementById('add-section').classList.add('hidden');
    document.getElementById('logs-section').classList.remove('hidden');
    
    document.getElementById('tab-logs').classList.add('tab-active');
    document.getElementById('tab-view').classList.remove('tab-active');
    document.getElementById('tab-add').classList.remove('tab-active');
    
    loadAuditLogs(); 
    
    // Auto-refresh bawat 3 segundo para sa mas "live" na pakiramdam
    if (!auditInterval) {
        auditInterval = setInterval(loadAuditLogs, 3000);
        console.log("Live Audit Trail: Monitoring login & changes...");
    }
};

function stopAuditRefresh() {
    if (auditInterval) {
        clearInterval(auditInterval);
        auditInterval = null;
    }
}

/**
 * TRIGGER GLOBAL SYNC
 * Tinatawag ito pagkatapos ng anumang database change para mag-update agad ang UI.
 */
async function triggerGlobalSync() {
    await initDataSDK(); // Update inventory
    if (!document.getElementById('logs-section').classList.contains('hidden')) {
        await loadAuditLogs(); // Update logs kung naka-open
    }
}

// --- CORE INVENTORY FUNCTIONS ---

async function initDataSDK() {
    try {
        const res = await fetch('dashboard.php?action=fetch'); 
        allProducts = await res.json();
        renderInventory(); 
    } catch (err) { console.error("Fetch error:", err); }
}

function getExpiryStatus(dateString) {
    if (!dateString) return 'none';
    const today = new Date();
    const expiryDate = new Date(dateString);
    const diffDays = Math.ceil((expiryDate - today) / (1000 * 60 * 60 * 24));
    if (diffDays <= 0) return 'expired';
    if (diffDays <= 30) return 'soon';
    return 'safe';
}

function highlightText(text, query) {
    if (!query) return text;
    const regex = new RegExp(`(${query})`, 'gi');
    return text.toString().replace(regex, '<mark class="bg-yellow-200 rounded-sm">$1</mark>');
}

function renderInventory() {
    const searchInput = document.getElementById('search-input');
    const categoryFilter = document.getElementById('category-filter');
    const list = document.getElementById('inventory-list');
    if (!searchInput || !categoryFilter || !list) return;

    const searchTerm = searchInput.value.trim().toLowerCase();
    const categoryTerm = categoryFilter.value;
    
    const filtered = allProducts.filter(p => {
        const nameMatch = p.product_name.toLowerCase().includes(searchTerm);
        const supplierMatch = (p.supplier || '').toLowerCase().includes(searchTerm);
        const categoryMatch = !categoryTerm || p.category === categoryTerm;
        return (nameMatch || supplierMatch) && categoryMatch;
    });

    updateStats(filtered);
    
    if (filtered.length === 0) {
        list.innerHTML = `<div class="p-12 text-center"><p class="text-[#7A6B5D]">Walang nahanap.</p></div>`;
        return;
    }

    list.innerHTML = '';
    filtered.forEach(product => {
        const isLow = parseInt(product.quantity) <= 5;
        const expiryStatus = getExpiryStatus(product.expiry_date);
        let expiryClass = expiryStatus === 'expired' ? 'bg-red-50/50' : '';
        let expiryLabel = expiryStatus === 'expired' ? "⚠️ EXPIRED" : (expiryStatus === 'soon' ? "⏳ SOON" : "✅ OK");

        const row = document.createElement('div');
        row.className = `p-4 flex flex-col md:flex-row items-start md:items-center gap-4 border-b ${expiryClass}`;
        row.innerHTML = `
            <div class="flex-1">
                <p class="font-semibold text-sm">${highlightText(product.product_name, searchTerm)}</p>
                <p class="text-xs text-[#7A6B5D]">${product.category} • ${highlightText(product.supplier || 'N/A', searchTerm)}</p>
                <p class="text-[10px] font-bold ${expiryStatus === 'expired' ? 'text-red-600' : 'text-[#B48C64]'}">${expiryLabel}: ${product.expiry_date || 'N/A'}</p>
            </div>
            <div class="flex items-center gap-8 text-sm">
                <div class="flex items-center border rounded-lg bg-white">
                    <button onclick="handleStockChange('${product.__backendId}', false)" class="w-8 h-8 text-red-600 font-bold">-</button>
                        <select id="qty-input-${product.__backendId}" class="px-2 text-xs font-bold appearance-none bg-transparent outline-none cursor-pointer">
                            ${Array.from({ length: 100 }, (_, i) => `<option value="${i + 1}">${i + 1}</option>`).join('')}
                        </select>
                    <button onclick="handleStockChange('${product.__backendId}', true)" class="w-8 h-8 text-green-600 font-bold">+</button>
                </div>
                <div class="text-center min-w-[50px]">
                    <p class="text-[10px] text-gray-400">Qty</p>
                    <p class="font-bold ${isLow ? 'text-red-600' : ''}">${product.quantity}</p>
                </div>
                <div class="text-center min-w-[80px]">
                    <p class="text-[10px] text-gray-400">Price</p>
                    <p class="font-bold">₱${Number(product.unit_price).toLocaleString()}</p>
                </div>
                <button onclick="handleDelete('${product.__backendId}')" class="text-red-300 hover:text-red-600">
                    <i data-lucide="trash-2" class="w-4 h-4"></i>
                </button>
            </div>`;
        list.appendChild(row);
    });
    lucide.createIcons();
}

function updateStats(data) {
    const lowStockCount = data.filter(p => parseInt(p.quantity) <= 5).length;
    const totalValue = data.reduce((acc, p) => acc + (parseInt(p.quantity) * parseFloat(p.unit_price)), 0);
    document.getElementById('stat-total').textContent = data.length;
    document.getElementById('stat-low').textContent = lowStockCount;
    document.getElementById('stat-value').textContent = '₱' + totalValue.toLocaleString();
}

// --- ACTIONS ---

window.handleStockChange = async (id, isAdding) => {
    const select = document.getElementById(`qty-input-${id}`);
    const amount = parseInt(select.value) || 1;
    const change = isAdding ? amount : -amount;
    
    try { 
        await fetch(`dashboard.php?action=update_stock&id=${id}&change=${change}`); 
        await triggerGlobalSync(); // Automatic update agad!
    } catch (err) { initDataSDK(); }
};

window.handleDelete = async (id) => {
    if (confirm("Sigurado ka bang nais mong burahin ang produktong ito?")) {
        await fetch(`dashboard.php?action=delete&id=${id}`);
        await triggerGlobalSync(); // Automatic update agad!
    }
};

// --- ADD PRODUCT HANDLER ---
document.getElementById('product-form').onsubmit = async (e) => {
    e.preventDefault();
    const data = {
        name: document.getElementById('form-name').value,
        category: document.getElementById('form-category').value,
        quantity: document.getElementById('form-qty').value,
        price: document.getElementById('form-price').value,
        expiry: document.getElementById('form-expiry').value,
        supplier: document.getElementById('form-supplier').value
    };
    await fetch('dashboard.php?action=add', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
    });
    showView();
    await triggerGlobalSync(); // Automatic update agad!
};

// --- LIVE AUDIT TRAIL LOGIC ---

async function loadAuditLogs() {
    try {
        const res = await fetch('dashboard.php?action=fetch_logs');
        const logs = await res.json();
        const list = document.getElementById('logs-list');
        if (!list) return;

        list.innerHTML = logs.map(l => {
            // Smart colors para sa iba't ibang actions
            let statusClass = "bg-blue-100 text-blue-700"; // Default
            if (l.action_made.includes('Added') || l.action_made.includes('Stock In')) statusClass = "bg-green-100 text-green-700";
            if (l.action_made.includes('Delete') || l.action_made.includes('Stock Out')) statusClass = "bg-red-100 text-red-700";
            if (l.action_made.includes('Logged In')) statusClass = "bg-purple-100 text-purple-700 font-black"; // Highlight login

            return `
                <tr class="border-b hover:bg-gray-50 transition-all duration-300">
                    <td class="px-6 py-4">
                        <div class="text-xs font-bold text-gray-900">${new Date(l.date_created).toLocaleDateString()}</div>
                        <div class="text-[10px] text-gray-400 uppercase">${new Date(l.date_created).toLocaleTimeString()}</div>
                    </td>
                    <td class="px-6 py-4">
                        <span class="px-2 py-1 rounded text-[11px] font-bold ${statusClass}">${l.action_made}</span>
                    </td>
                    <td class="px-6 py-4">
                        <div class="flex items-center gap-2">
                            <div class="relative">
                                <div class="w-7 h-7 rounded-full bg-[#B48C64] text-white flex items-center justify-center text-[10px] font-bold shadow-sm">
                                    ${l.performed_by ? l.performed_by.charAt(0).toUpperCase() : '?'}
                                </div>
                                <div class="absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 bg-green-500 border-2 border-white rounded-full"></div>
                            </div>
                            <span class="text-xs font-bold text-[#3D3228]">${l.performed_by || 'Admin'}</span>
                        </div>
                    </td>
                </tr>
            `;
        }).join('');
    } catch (err) {
        console.error("Audit Trail failed to load:", err);
    }
}

// --- INITIALIZATION ---

document.addEventListener('DOMContentLoaded', () => {
    initDataSDK();
    
    // ... search & category listeners remain the same ...

    // Tab Listeners
    const tabView = document.getElementById('tab-view');
    const tabAdd = document.getElementById('tab-add');
    const tabLogs = document.getElementById('tab-logs');

    if (tabView) tabView.onclick = showView;
    if (tabAdd) tabAdd.onclick = showAdd;
    if (tabLogs) tabLogs.onclick = showLogs;

    const cancelBtn = document.getElementById('form-cancel');
    if (cancelBtn) cancelBtn.onclick = showView;
});

function resetForm() { 
    const form = document.getElementById('product-form');
    if (form) form.reset(); 
}