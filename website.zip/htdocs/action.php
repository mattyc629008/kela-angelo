<?php
ini_set('display_errors', 0);
error_reporting(0);
ob_start();

session_start();
header('Content-Type: application/json; charset=utf-8');

// 1. Load DB class
try {
    require_once('DBConnection.php');
} catch (Throwable $e) {
    ob_end_clean();
    echo json_encode(['status' => 'failed', 'msg' => 'DB load error: ' . $e->getMessage()]);
    exit;
}

Class Actions extends DBConnection {
    function __construct()  { parent::__construct(); }
    function __destruct()   { parent::__destruct(); }

    function save_log($user_id, $action_made) {
        $action_made = $this->conn->real_escape_string($action_made);
        $sql = "INSERT INTO `logs` (`user_id`, `action_made`) VALUES ('{$user_id}', '{$action_made}')";
        return $this->conn->query($sql);
    }

    function login() {
        $email    = $this->conn->real_escape_string($_POST['email']    ?? '');
        $password = $_POST['password'] ?? '';

        if (empty($email) || empty($password)) {
            return json_encode(['status' => 'failed', 'msg' => 'Email and password are required.']);
        }

        $result = $this->conn->query("SELECT * FROM `users` WHERE `email` = '{$email}'");

        if (!$result) {
            return json_encode([
                'status' => 'failed',
                'msg'    => 'DB error: ' . $this->conn->error
            ]);
        }

        $row = $result->fetch_assoc();

        if (!$row || !password_verify($password, $row['password'])) {
            return json_encode(['status' => 'failed', 'msg' => 'Invalid email or password.']);
        }

        foreach ($row as $key => $value) {
            if (!is_numeric($key)) $_SESSION[$key] = $value;
        }
        $this->save_log($_SESSION['id'], "User logged into the system.");
        return json_encode(['status' => 'success', 'msg' => 'Login successful.']);
    }

    function logout() {
        if (isset($_SESSION['id'])) {
            $this->save_log($_SESSION['id'], "User logged out from the system.");
        }
        session_destroy();
        ob_end_clean();
        header_remove('Content-Type');
        header("Location:./login.php");
        exit;
    }

    function save_inventory() {
        extract($_POST);
        $data = "";
        foreach ($_POST as $key => $value) {
            if (!in_array($key, ['id'])) {
                $value = $this->conn->real_escape_string($value);
                if (!empty($data)) $data .= ", ";
                $data .= " `{$key}` = '{$value}' ";
            }
        }
        if (empty($id)) {
            $sql    = "INSERT INTO `inventory` SET {$data}";
            $action = "Stock In: Added batch for Product ID: {$product_id}, Qty: {$quantity}";
        } else {
            $sql    = "UPDATE `inventory` SET {$data} WHERE id = '{$id}'";
            $action = "Inventory Update: Modified batch ID: {$id}";
        }
        $save = $this->conn->query($sql);
        $resp['status'] = $save ? "success" : "failed";
        if (!$save) $resp['msg'] = "Error: " . $this->conn->error;
        else $this->save_log($_SESSION['id'], $action);
        return json_encode($resp);
    }

    function stock_out_fifo() {
        extract($_POST);
        $qty_needed = $quantity_to_out;
        $batches    = $this->conn->query(
            "SELECT * FROM `inventory` WHERE product_id = '{$product_id}' AND quantity > 0 ORDER BY date_received ASC"
        );
        if ($batches->num_rows > 0) {
            while ($row = $batches->fetch_assoc()) {
                if ($qty_needed <= 0) break;
                $bid = $row['id']; $bqty = $row['quantity'];
                if ($bqty >= $qty_needed) {
                    $this->conn->query("UPDATE `inventory` SET quantity = '" . ($bqty - $qty_needed) . "' WHERE id = '{$bid}'");
                    $qty_needed = 0;
                } else {
                    $qty_needed -= $bqty;
                    $this->conn->query("UPDATE `inventory` SET quantity = 0 WHERE id = '{$bid}'");
                }
            }
            $this->save_log($_SESSION['id'], "Stock Out (FIFO): Removed {$quantity_to_out} units from Product ID: {$product_id}");
            return json_encode(['status' => 'success']);
        }
        return json_encode(['status' => 'failed', 'msg' => 'No available stock for this product.']);
    }

    function save_member() {
        extract($_POST);
        $data = "";
        foreach ($_POST as $key => $value) {
            if (!in_array($key, ['id'])) {
                $value = $this->conn->real_escape_string($value);
                if (!empty($data)) $data .= ", ";
                $data .= " `{$key}` = '{$value}' ";
            }
        }
        if (empty($id)) {
            $sql    = "INSERT INTO `members` SET {$data}";
            $action = "Added member: {$firstname} {$lastname}";
        } else {
            $sql    = "UPDATE `members` SET {$data} WHERE id = '{$id}'";
            $action = "Updated member ID: {$id}";
        }
        $save = $this->conn->query($sql);
        if ($save) $this->save_log($_SESSION['id'], $action);
        return json_encode(['status' => $save ? 'success' : 'failed']);
    }
}

$action_type = isset($_GET['a']) ? $_GET['a'] : "";

// 2. Instantiate WHILE ob_start() is still active so mysqli warnings
//    get buffered, not leaked into the JSON response.
try {
    $handler = new Actions();
} catch (Throwable $e) {
    ob_end_clean();
    echo json_encode(['status' => 'failed', 'msg' => 'DB connection failed: ' . $e->getMessage()]);
    exit;
}

// 3. Only NOW wipe the buffer — any mysqli warnings above are safely discarded.
ob_end_clean();

switch ($action_type) {
    case "login":          echo $handler->login();                                          break;
    case "logout":              $handler->logout();                                         break;
    case "save_inventory": echo $handler->save_inventory();                                 break;
    case "stock_out_fifo": echo $handler->stock_out_fifo();                                 break;
    case "save_member":    echo $handler->save_member();                                    break;
    case "save_log":       echo $handler->save_log($_SESSION['id'], $_POST['action_made']); break;
    default:               echo json_encode(['status' => 'failed', 'msg' => 'Unknown action.']); break;
}