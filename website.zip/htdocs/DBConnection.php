<?php
/**
 * DBConnection.php
 * FIXED: die() replaced with JSON-safe error output so it never
 * breaks JSON.parse() in the browser.
 */
if (!class_exists('DBConnection')) {
    class DBConnection {
        protected $host     = "localhost";
        protected $username = "root";
        protected $password = "";
        protected $database = "bhea_cay_db";
        public    $conn;

        public function __construct() {
            if (!isset($this->conn)) {
                $this->conn = new mysqli(
                    $this->host,
                    $this->username,
                    $this->password,
                    $this->database
                );

                if ($this->conn->connect_error) {
                    // FIXED: was die("Hindi makakonekta...") which outputs plain text
                    // and breaks JSON.parse() in the browser.
                    // Now throws an exception so action.php can catch it and
                    // return a proper JSON error instead.
                    throw new RuntimeException(
                        'Hindi makakonekta sa database: ' . $this->conn->connect_error
                    );
                }
            }
        }

        public function __destruct() {
            if (isset($this->conn) && $this->conn instanceof mysqli) {
                $this->conn->close();
            }
        }
    }
}
?>