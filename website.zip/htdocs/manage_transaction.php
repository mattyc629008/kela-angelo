<?php
require_once('./DBConnection.php');
if(isset($_GET['id'])){
    // Fetch existing transaction details if we are in update mode
    $qry = $conn->query("SELECT * FROM `transactions` WHERE id = '{$_GET['id']}'");
    if($qry->num_rows > 0){
        foreach($qry->fetch_array() as $k => $v){
            if(!is_numeric($k))
            $$k = $v;
        }
    }
}
?>
<div class="container-fluid">
    <form action="" id="transaction-form">
        <input type="hidden" name="id" value="<?php echo isset($id) ? $id : '' ?>">
        
        <div class="form-group mb-3">
            <label for="member_id" class="control-label">Select Member</label>
            <select name="member_id" id="member_id" class="form-select form-select-sm rounded-0" required>
                <option value="" disabled <?php echo !isset($member_id) ? "selected" : "" ?>>Please select a member</option>
                <?php 
                $members = $conn->query("SELECT id, firstname, lastname FROM members ORDER BY lastname ASC");
                while($row = $members->fetch_assoc()):
                ?>
                <option value="<?php echo $row['id'] ?>" <?php echo isset($member_id) && $member_id == $row['id'] ? "selected" : "" ?>>
                    <?php echo $row['lastname'] . ", " . $row['firstname'] ?>
                </option>
                <?php endwhile; ?>
            </select>
        </div>

        <div class="form-group mb-3">
            <label for="amount" class="control-label">Transaction Amount</label>
            <input type="number" step="any" name="amount" class="form-control form-control-sm rounded-0 text-end" value="<?php echo isset($amount) ? $amount : "" ?>" required>
        </div>

        <div class="form-group mb-3">
            <label for="transaction_type" class="control-label">Transaction Type</label>
            <select name="transaction_type" id="transaction_type" class="form-select form-select-sm rounded-0" required>
                <option value="Enrollment Fee" <?php echo isset($type) && $type == 'Enrollment Fee' ? 'selected' : '' ?>>Enrollment Fee</option>
                <?php /* You can add more types here based on your research requirements */ ?>
                <option value="Monthly Subscription" <?php echo isset($type) && $type == 'Monthly Subscription' ? 'selected' : '' ?>>Monthly Subscription</option>
                <option value="Personal Training" <?php echo isset($type) && $type == 'Personal Training' ? 'selected' : '' ?>>Personal Training</option>
            </select>
        </div>

        <div class="form-group mb-3">
            <label for="remarks" class="control-label">Remarks</label>
            <textarea rows="2" name="remarks" class="form-control form-control-sm rounded-0"><?php echo isset($remarks) ? $remarks : "" ?></textarea>
        </div>
    </form>
</div>

<script>
$(function(){
    $('#transaction-form').submit(function(e){
        e.preventDefault();
        $('.pop_msg').remove();
        var _this = $(this);
        var _el = $('<div>').addClass('pop_msg');
        
        $('#uni_modal button').attr('disabled', true);
        $('#uni_modal button[type="submit"]').text('Recording transaction...');

        $.ajax({
            url: './Actions.php?a=save_transaction',
            data: new FormData($(this)[0]),
            cache: false,
            contentType: false,
            processData: false,
            method: 'POST',
            type: 'POST',
            dataType: 'json',
            error: err => {
                console.log(err);
                _el.addClass('alert alert-danger').text("An error occurred while saving the transaction.");
                _this.prepend(_el);
                _el.show('slow');
                $('#uni_modal button').attr('disabled', false);
                $('#uni_modal button[type="submit"]').text('Save');
            },
            success: function(resp){
                if(resp.status == 'success'){
                    _el.addClass('alert alert-success').text(resp.msg);
                    $('#uni_modal').on('hide.bs.modal', function(){
                        location.reload();
                    });
                    _this.get(0).reset();
                } else {
                    _el.addClass('alert alert-danger').text(resp.msg);
                }
                _this.prepend(_el);
                _el.show('slow');
                $('#uni_modal button').attr('disabled', false);
                $('#uni_modal button[type="submit"]').text('Save');
            }
        });
    });
});
</script>