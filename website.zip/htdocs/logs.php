<?php 
/**
 * Ang file na ito ay ang viewer para sa System Audit Trail.
 * Kinukuha nito ang data mula sa logs table at isinasama ang 
 * pangalan ng user mula sa users table.
 */
require_once('./DBConnection.php'); 
?>
<div class="container py-5">
    <div class="d-flex w-100 align-items-center">
        <h3 class="col-auto flex-grow-1"><b>System Audit Trail</b></h3>
        <button class="btn btn-sm btn-primary rounded-0" type="button" onclick="location.reload()">
            <i class="fa fa-retweet"></i> Refresh Activity List
        </button>
    </div>
    <hr>
    <div class="card shadow-sm">
        <div class="card-body">
            <table class="table table-bordered table-striped table-hover" id="audit-log-table">
                <thead>
                    <tr>
                        <th class="py-2 px-2 text-center">#</th>
                        <th class="py-2 px-2">Date and Time</th>
                        <th class="py-2 px-2">System User</th>
                        <th class="py-2 px-2">Action Performed</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    /**
                     * Ginagamit natin ang INNER JOIN upang makuha ang username 
                     * na tumutugma sa user_id na nasa logs table.
                     */
                    $sql = "SELECT l.*, u.username FROM `logs` l INNER JOIN users u ON l.user_id = u.id ORDER BY l.date_created DESC";
                    $qry = $conn->query($sql);
                    $i = 1;
                    if($qry->num_rows > 0):
                        while($row = $qry->fetch_assoc()):
                    ?>
                    <tr>
                        <td class="py-1 px-2 text-center"><?php echo $i++ ?></td>
                        <td class="py-1 px-2"><?php echo date("M d, Y H:i A", strtotime($row['date_created'])) ?></td>
                        <td class="py-1 px-2"><?php echo $row['username'] ?></td>
                        <td class="py-1 px-2"><?php echo $row['action_made'] ?></td>
                    </tr>
                    <?php 
                        endwhile; 
                    else:
                    ?>
                    <tr>
                        <th class="text-center" colspan="4">No activity logs are currently recorded in the database.</th>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script>
    $(function(){
        /**
         * Ang DataTables ay nakakatulong upang madaling mahanap ng mga 
         * researcher ang mga partikular na transaksyon o gumagamit ng system.
         */
        if($('#audit-log-table').length > 0){
            if ( ! $.fn.DataTable.isDataTable( '#audit-log-table' ) ) {
                $('#audit-log-table').DataTable({
                    "order": [[ 1, "desc" ]],
                    "language": {
                        "emptyTable": "No data is available in the audit trail."
                    },
                    "drawCallback": function() {
                        $('.dataTables_paginate > .pagination').addClass('pagination-sm')
                    }
                });
            }
        }
    })
</script>